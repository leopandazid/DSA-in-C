#include<stdio.h>
#include"sll.h"

void initList(NODE** phead)
{
	*phead=NULL;
}