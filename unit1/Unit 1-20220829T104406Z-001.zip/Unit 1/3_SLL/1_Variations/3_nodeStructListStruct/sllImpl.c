#include<stdio.h>
#include"sll.h"

void initList(LLIST *pl)
{
	pl->head=NULL;
}