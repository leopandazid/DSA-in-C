typedef struct node
{
	int info;
	struct node *next;
}NODE;

NODE* initList(NODE* head);