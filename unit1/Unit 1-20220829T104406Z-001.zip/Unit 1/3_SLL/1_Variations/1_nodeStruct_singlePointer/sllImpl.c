#include<stdio.h>
#include"sll.h"

NODE* initList(NODE* head)
{
	head=NULL;
	return head;
}